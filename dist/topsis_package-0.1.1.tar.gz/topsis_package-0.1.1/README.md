# TOPSIS Decision Making Python Package

This Python package implements the TOPSIS (Technique for Order Preference by Similarity to Ideal Solution) decision-making method.

## Installation

To install the package, run:

```bash
pip install topsis-package
