# topsis_package/__init__.py

from .topsis import run_topsis
